CHANGELOG
=========

4.4.0
-----

 * The bundle is deprecated and will be removed in 5.0.

4.2.0
-----

 * Added ability to display the current hostname address if available when binding to 0.0.0.0

3.4.0
-----

 * WebServer can now use `*` as a wildcard to bind to 0.0.0.0 (INADDR_ANY)

3.3.0
-----

 * Added bundle
