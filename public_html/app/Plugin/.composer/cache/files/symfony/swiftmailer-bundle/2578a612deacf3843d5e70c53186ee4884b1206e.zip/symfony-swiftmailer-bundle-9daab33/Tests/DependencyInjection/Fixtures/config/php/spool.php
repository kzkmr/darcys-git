<?php

$container->loadFromExtension('swiftmailer', [
    'spool' => true,
]);
