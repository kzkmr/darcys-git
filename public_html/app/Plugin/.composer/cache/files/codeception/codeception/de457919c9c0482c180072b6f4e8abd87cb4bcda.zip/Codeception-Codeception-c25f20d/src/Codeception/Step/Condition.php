<?php
namespace Codeception\Step;

use Codeception\Step as CodeceptionStep;

class Condition extends CodeceptionStep
{
}
