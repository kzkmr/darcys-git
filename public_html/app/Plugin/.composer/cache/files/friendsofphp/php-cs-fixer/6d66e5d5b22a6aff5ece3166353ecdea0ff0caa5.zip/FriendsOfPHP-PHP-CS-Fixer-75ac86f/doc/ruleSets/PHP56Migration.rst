============================
Rule set ``@PHP56Migration``
============================

Rules to improve code for PHP 5.6 compatibility.

Rules
-----

- `@PHP54Migration <./PHP54Migration.rst>`_
