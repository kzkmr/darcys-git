<?php
namespace Aws\Exception;

/**
 * Class CryptoPolyfillException
 * @package Aws\Exception
 */
class CryptoPolyfillException extends \RuntimeException
{

}
