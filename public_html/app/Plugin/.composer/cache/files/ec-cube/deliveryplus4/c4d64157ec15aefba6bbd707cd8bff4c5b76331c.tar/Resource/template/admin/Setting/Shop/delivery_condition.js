<script>
    $(function() {
        $elem = $('#deliveryplus');
        $('.card:eq(0)', this).after($elem.html());
        $elem.remove();
    });
</script>
