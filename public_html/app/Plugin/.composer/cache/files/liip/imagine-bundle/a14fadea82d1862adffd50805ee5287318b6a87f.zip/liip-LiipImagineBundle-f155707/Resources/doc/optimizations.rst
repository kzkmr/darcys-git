

Optimizations
=============

.. toctree::
    :maxdepth: 2

    optimizations/resolve-cache-images-in-background
    optimizations/avoid-redirects
