

Data Loaders
============

A number of built-in data loaders are available:

.. toctree::
    :maxdepth: 1
    :glob:

    data-loader/*

When the built-in loaders do not fit your requirements, you can write your own
:doc:`custom data loaders <data-loaders-custom>`.
